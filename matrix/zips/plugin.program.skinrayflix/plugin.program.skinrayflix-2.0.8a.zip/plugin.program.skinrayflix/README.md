# plugin.program.skinrayflix
Demande d'aide au developpement :

Menu principal :

1. Script 1 > Liaison avec : /resources/lib/skin_save1.py (thumb = /resources/media/icone.png) - fanart (/resources/media/fanart.jpg)
2. Script 2 > Liaison avec : /resources/lib/skin_save2.py (thumb = /resources/media/icone.png) - fanart (/resources/media/fanart.jpg)

Besoin d'un exemple de constitution pour le fichier "defaut.py".

Merci à tous pour votre aide !